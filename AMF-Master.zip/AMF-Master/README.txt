AMF Bot V1.0.4

How to use:
-Update the bot with AMFBot Updater to make sure you're using the latest version.
-Check the box of the actions you wish to perform on each network.
-Select networks and set max number of clicks per network.
-Hit start and sign in. Make sure you're signed in to each network account.
-The bot will take random breaks and perform actions with human-like delays.
-Not recommended to collect more than 2500-3000 points per day to avoid being banned by AddMeFast.